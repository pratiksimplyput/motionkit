#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
printf '\nMotionKit — Mac development installer\n\n'
printf 'This unsigned test build installs a CEP panel and enables unsigned CEP extensions.\n'
printf 'After Effects must be closed. No administrator password is needed.\n\n'
read -r -p 'Continue? [y/N] ' answer
case "$answer" in y|Y|yes|YES) ;; *) exit 0 ;; esac
if pgrep -f '/Adobe After Effects[^/]*/.*After Effects' >/dev/null 2>&1; then
  printf '\nClose After Effects, then run this installer again.\n'
  read -r -p 'Press Return to close.' unused
  exit 1
fi
source_dir="$PWD/com.simplyput.motionkit"
target_dir="$HOME/Library/Application Support/Adobe/CEP/extensions/com.simplyput.motionkit"
if [[ ! -f "$source_dir/CSXS/manifest.xml" ]]; then
  printf '\nMissing panel files. Extract the complete ZIP before running this installer.\n'
  exit 1
fi
mkdir -p "$(dirname "$target_dir")"
if [[ -e "$target_dir" ]]; then
  backup_dir="$HOME/Library/Application Support/MotionKit/Backups/$(date +%Y%m%d-%H%M%S)-$$"
  mkdir -p "$backup_dir"
  mv "$target_dir" "$backup_dir/com.simplyput.motionkit"
  printf '\nPrevious installation preserved in %s\n' "$backup_dir"
fi
cp -R "$source_dir" "$target_dir"
# These development preferences cover CEP 11 and 12; Adobe's actual runtime
# still needs verification on the target AE 26 installation.
for runtime in 11 12; do
  defaults write "com.adobe.CSXS.$runtime" PlayerDebugMode -string 1
done
printf '\nInstalled MotionKit.\nOpen After Effects → Window → Extensions → MotionKit.\n'
printf '\nDevelopment loading enabled for CEP 11 and 12. This preference allows other unsigned CEP panels too.\n'
printf 'To disable after testing (MotionKit will then need signing):\n'
printf 'defaults delete com.adobe.CSXS.11 PlayerDebugMode\n'
printf 'defaults delete com.adobe.CSXS.12 PlayerDebugMode\n'
printf '\nTest: select a rectangle shape layer, apply 24 px, then press Cmd+Z.\n'
read -r -p 'Press Return to finish.' unused
